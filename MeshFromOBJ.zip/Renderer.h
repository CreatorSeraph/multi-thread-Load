#pragma once
#include "Component.h"
#include "CFrame.h"

#include <variant>

enum RenderType : char
{
	mesh,
	vecmesh,
	img,
	vecimg
};

class Renderer :
	public Component
{
private:
	RenderType renderType;

	variant<CMeshLoader*, vector<CMeshLoader*>*, texture*, vector<texture*>*> resource;

	//CMeshLoader* Mesh3d = nullptr ;
	//vector<CMeshLoader*>* VecMesh3d = { nullptr, };

	//texture* Img = nullptr;
	//vector<texture*>* VecImg = { nullptr, };

	CFrame frame;

public:
	Renderer(RenderType type, const wstring& key, const wstring& path, int count = 0);
	virtual ~Renderer();

	CFrame& Getframe() { return frame; }

	//void AddMesh(const wstring& key, const wstring& path);
	//void AddVecMesh(const wstring& key, const wstring& path, int count);
	//
	//void AddImg(const wstring& key, const wstring& path);
	//void AddVecImg(const wstring& key, const wstring& path, int count);

	virtual void Init() override;

	virtual void Render();

	virtual void Destroy() override;

	
};

