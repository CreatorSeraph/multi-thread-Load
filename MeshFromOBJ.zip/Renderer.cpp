#include "DXUT.h"
#include "Renderer.h"
#include "CGameObject.h"
#include "Transform.h"
#include "MeshLoader.h"

//http://occamsrazr.net/tt/323 variant�� �����ΰ�?
//https://www.kudryavka.me/?p=267 variant�� �̿��� visit������ ����, visit�� ��� ����ϴ°�

template<class... Ts> struct overload : Ts... { using Ts::operator()...; };
template<class... Ts> overload(Ts...)->overload<Ts...>;//��! ���ø�!

Renderer::Renderer(RenderType type, const wstring& key, const wstring& path, int count)
	:renderType(type)
{
	switch (type)
	{
	case mesh:
		resource = IMAGE->GetMesh(key, path);
		break;
	case vecmesh:
		resource = IMAGE->GetVecMesh(key, path, count);
		break;
	case img:
		resource = IMAGE->GetTexture(key, path);
		break;
	case vecimg:
		resource = IMAGE->GetVecTexture(key, path, count);
		break;
	default:
		break;
	}
}

Renderer::~Renderer()
{
}

void Renderer::Init()
{
	GetGameObject()->renderer = this;
	OBJMANAGER->AddRenderer(this);
}

void Renderer::Render()
{
	std::visit(overload{
		[&](CMeshLoader* Mesh3d) {
			g_device->SetTransform(D3DTS_WORLD, &GetTransform()->GetWorldMatrix());

			for (int i = 0; i < Mesh3d->GetNumMaterials(); ++i)
			{
				g_device->SetTexture(0, Mesh3d->GetMaterial(i)->pTexture);
				Mesh3d->GetMesh()->DrawSubset(i);
			}
		},
		[&](vector<CMeshLoader*>* VecMesh3d) {
			g_device->SetTransform(D3DTS_WORLD, &GetTransform()->GetWorldMatrix());
			g_device->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);

			for (int i = 0; i < (*VecMesh3d)[0]->GetNumMaterials(); ++i)
			{
				//g_device->SetTexture(0, (*VecMesh3d)[frame.CurF]->GetMaterial(i)->pTexture)
				g_device->SetTexture(0, (*VecMesh3d)[0]->GetMaterial(i)->pTexture);
				(*VecMesh3d)[frame.CurF]->GetMesh()->DrawSubset(i);
			}
		},
		[&](texture* Img) {
			IMAGE->GetSprite()->SetTransform(&GetTransform()->GetWorldMatrix());
			IMAGE->GetSprite()->Draw(Img->texturePtr, nullptr, &Vector3(0.f, 0.f, 0.f), nullptr, D3DCOLOR_ARGB(255,255,255,255));
		},
		[&](vector<texture*>* VecImg) {
			IMAGE->GetSprite()->SetTransform(&GetTransform()->GetWorldMatrix());
			IMAGE->GetSprite()->Draw((*VecImg)[frame.CurF]->texturePtr, nullptr, &Vector3(0.f, 0.f, 0.f), nullptr, D3DCOLOR_ARGB(255, 255, 255, 255));
		}
		}, resource);
	/* ���� ������ �ڵ�� �̰��� �ִ�
	//Matrix testmat;
	switch (renderType)
	{
	case(RenderType::mesh):
		g_device->SetTransform(D3DTS_WORLD, &GetTransform()->GetWorldMatrix());

		for (int i = 0; i < Mesh3d->GetNumMaterials(); ++i)
		{
			g_device->SetTexture(0, Mesh3d->GetMaterial(i)->pTexture);
			Mesh3d->GetMesh()->DrawSubset(i);
		}
		break;
	case(RenderType::img):
		IMAGE->GetSprite()->SetTransform(&GetTransform()->GetWorldMatrix());
		IMAGE->GetSprite()->Draw(Img->texturePtr, nullptr, &Vector3(0.f, 0.f, 0.f), nullptr, D3DCOLOR_ARGB(255,255,255,255));
		break;
	case(RenderType::vecmesh):

		//testmat = GetTransform()->GetWorldMatrix();


		g_device->SetTransform(D3DTS_WORLD, &GetTransform()->GetWorldMatrix());
		g_device->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);

		for (int i = 0; i < (*VecMesh3d)[0]->GetNumMaterials(); ++i)
		{
			//g_device->SetTexture(0, (*VecMesh3d)[frame.CurF]->GetMaterial(i)->pTexture)
			g_device->SetTexture(0, (*VecMesh3d)[0]->GetMaterial(i)->pTexture);
			(*VecMesh3d)[frame.CurF]->GetMesh()->DrawSubset(i);
		}
		break;
		//g_device->SetRenderState(D3DRS_CULLMODE, D3DCULL_);
	
	case(RenderType::vecimg):
		IMAGE->GetSprite()->SetTransform(&GetTransform()->GetWorldMatrix());
		IMAGE->GetSprite()->Draw((*VecImg)[frame.CurF]->texturePtr, nullptr, &Vector3(0.f, 0.f, 0.f), nullptr, D3DCOLOR_ARGB(255, 255, 255, 255));
		break;

	}*/
	

}


void Renderer::Destroy()
{
	OBJMANAGER->DeleteRenderer(this);
	if (GetGameObject()->renderer == this)
		GetGameObject()->renderer = nullptr;
}
